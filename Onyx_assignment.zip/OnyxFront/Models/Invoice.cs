using System.Collections.Generic;

public class Invoice
{
    public List<Observation> Observations { get; set; }
}
