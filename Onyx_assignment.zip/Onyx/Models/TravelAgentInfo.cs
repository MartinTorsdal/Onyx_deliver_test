class TravelAgentInfo
{
    public string TravelAgent { get; set; }
    public int TotalNumberOfNights { get; set; }
}
