using System.Collections.Generic;

class Invoice
{
    public List<Observation> Observations { get; set; }
}
