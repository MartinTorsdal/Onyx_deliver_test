class Observation
{
    public string TravelAgent { get; set; }
    public string GuestName { get; set; }
    public int NumberOfNights { get; set; }
}
